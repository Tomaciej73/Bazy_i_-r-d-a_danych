--------------------------------------------------------
--  DDL for Procedure ADD_CITY
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "ADD_CITY" (
    p_id IN NUMBER,
    p_city_name IN VARCHAR2
) AS
BEGIN
    INSERT INTO City (ID, CITY_NAME) 
    VALUES (p_id, p_city_name);
    COMMIT;
END add_city;
