--------------------------------------------------------
--  DDL for Procedure ADD_COUNTRY
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "ADD_COUNTRY" (
    p_id IN NUMBER,
    p_country_name IN VARCHAR2
) AS
BEGIN
    INSERT INTO Country (ID, COUNTRY_NAME)
    VALUES (p_id, p_country_name);
    COMMIT;
END add_country;
