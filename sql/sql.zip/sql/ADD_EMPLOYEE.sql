--------------------------------------------------------
--  DDL for Procedure ADD_EMPLOYEE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "ADD_EMPLOYEE" (
    p_first_name IN VARCHAR2, 
    p_last_name IN VARCHAR2, 
    p_salary IN NUMBER
) AS
    v_employee_id NUMBER;
BEGIN
    IF p_salary > 20000 THEN
        RAISE_APPLICATION_ERROR(-20003, 'Salary cannot exceed 20000.');
    END IF;

    INSERT INTO employees (employee_id, first_name, last_name, salary, hire_date, job_id)
    VALUES (employees_seq.NEXTVAL, p_first_name, p_last_name, p_salary, SYSDATE, 'IT_PROG');  -- Przykład z domyślnym job_id

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Employee added successfully: ' || p_first_name || ' ' || p_last_name || ', Salary: ' || p_salary);

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END add_employee;
