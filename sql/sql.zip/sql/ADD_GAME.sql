--------------------------------------------------------
--  DDL for Procedure ADD_GAME
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "ADD_GAME" (
    p_id IN NUMBER,
    p_game_date IN DATE,
    p_home_team_id IN NUMBER,
    p_away_team_id IN NUMBER,
    p_home_score IN NUMBER,
    p_away_score IN NUMBER,
    p_tournament_id IN NUMBER,
    p_city_id IN NUMBER,
    p_country_id IN NUMBER,
    p_neutral IN NUMBER
) AS
BEGIN
    INSERT INTO GAME (
        ID, GAME_DATE, HOME_TEAM_ID, AWAY_TEAM_ID, HOME_SCORE, AWAY_SCORE,
        TOURNAMENT_ID, CITY_ID, COUNTRY_ID, NEUTRAL
    ) 
    VALUES (
        p_id, p_game_date, p_home_team_id, p_away_team_id, p_home_score, p_away_score,
        p_tournament_id, p_city_id, p_country_id, p_neutral
    );
    COMMIT;
END add_game;
