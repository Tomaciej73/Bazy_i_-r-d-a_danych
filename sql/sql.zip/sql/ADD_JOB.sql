--------------------------------------------------------
--  DDL for Procedure ADD_JOB
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "ADD_JOB" (
    p_job_id IN VARCHAR2, 
    p_job_title IN VARCHAR2
) AS
BEGIN
    INSERT INTO jobs (job_id, job_title)
    VALUES (p_job_id, p_job_title);

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Job added successfully: ' || p_job_id || ' - ' || p_job_title);

EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('Error: Duplicate Job_id, job already exists.');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END add_job;
