--------------------------------------------------------
--  DDL for Procedure ADD_TEAM
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "ADD_TEAM" (
    p_id IN NUMBER,
    p_team_name IN VARCHAR2
) AS
BEGIN
    INSERT INTO Team (ID, TEAM_NAME)
    VALUES (p_id, p_team_name);
    COMMIT;
END add_team;
