--------------------------------------------------------
--  DDL for Procedure ADD_TOURNAMENT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "ADD_TOURNAMENT" (
    p_id IN NUMBER,
    p_tournament_name IN VARCHAR2
) AS
BEGIN
    INSERT INTO Tournament (ID, TOURNAMENT_NAME)
    VALUES (p_id, p_tournament_name);
    COMMIT;
END add_tournament;
