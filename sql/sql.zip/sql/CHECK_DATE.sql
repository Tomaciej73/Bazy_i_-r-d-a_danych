--------------------------------------------------------
--  DDL for Function CHECK_DATE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "CHECK_DATE" (p_date DATE) 
RETURN DATE IS
    e_future_date EXCEPTION;
BEGIN
    IF p_date < SYSDATE THEN
        RETURN p_date;
    ELSE
        RAISE e_future_date; -- Rzucenie wyjątku, gdy data jest nowsza lub równa dzisiejszej
    END IF;
EXCEPTION
    WHEN e_future_date THEN
        RAISE_APPLICATION_ERROR(-20000, 'Data nie może być z przyszłości lub dzisiejsza. Podaj wcześniejszą datę.');
END check_date;
