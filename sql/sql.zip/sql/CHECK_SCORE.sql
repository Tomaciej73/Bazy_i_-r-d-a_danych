--------------------------------------------------------
--  DDL for Function CHECK_SCORE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "CHECK_SCORE" (p_score NUMBER)
RETURN NUMBER IS
    e_negative_score EXCEPTION; -- własny wyjątek dla ujemnego wyniku
BEGIN
    IF p_score < 0 THEN
        RAISE e_negative_score;
    ELSE
        RETURN p_score;
    END IF;
EXCEPTION
    WHEN e_negative_score THEN
        RAISE_APPLICATION_ERROR(-20001, 'Wynik nie może być liczbą ujemną.');
END check_score;
