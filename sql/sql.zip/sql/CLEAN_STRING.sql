--------------------------------------------------------
--  DDL for Function CLEAN_STRING
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "CLEAN_STRING" (input_string IN VARCHAR2)
RETURN VARCHAR2 IS
    cleaned_string VARCHAR2(100);
    e_invalid_string EXCEPTION; -- własny wyjątek dla nieprawidłowego łańcucha
BEGIN
    cleaned_string := REGEXP_REPLACE(input_string, '[^a-zA-Z0-9 -]', '');

    IF cleaned_string IS NULL OR TRIM(cleaned_string) = '' THEN
        RAISE e_invalid_string;
    END IF;

    RETURN cleaned_string;

EXCEPTION
    WHEN e_invalid_string THEN
        RAISE_APPLICATION_ERROR(-20002, 'Ciąg znaków jest nieprawidłowy lub pusty.');
END clean_string;
