--------------------------------------------------------
--  DDL for Table COUNTRIES
--------------------------------------------------------

  CREATE TABLE "COUNTRIES" ("COUNTRY_ID" CHAR(2), "COUNTRY_NAME" VARCHAR2(50), "REGION_ID" NUMBER)
