--------------------------------------------------------
--  DDL for Procedure DELETE_CITY
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "DELETE_CITY" (
    p_id IN NUMBER
) AS
BEGIN
    DELETE FROM City WHERE ID = p_id;
    COMMIT;
END delete_city;
