--------------------------------------------------------
--  DDL for Procedure DELETE_COUNTRY
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "DELETE_COUNTRY" (
    p_id IN NUMBER
) AS
BEGIN
    DELETE FROM Country WHERE ID = p_id;
    COMMIT;
END delete_country;
