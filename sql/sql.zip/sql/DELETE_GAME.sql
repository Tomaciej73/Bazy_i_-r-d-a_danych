--------------------------------------------------------
--  DDL for Procedure DELETE_GAME
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "DELETE_GAME" (
    p_id IN NUMBER
) AS
BEGIN
    DELETE FROM GAME WHERE ID = p_id;
    COMMIT;
END delete_game;
