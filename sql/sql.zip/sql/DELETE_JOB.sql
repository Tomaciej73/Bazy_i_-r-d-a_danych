--------------------------------------------------------
--  DDL for Procedure DELETE_JOB
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "DELETE_JOB" (
    p_job_id IN VARCHAR2
) AS
    rows_deleted INTEGER;
BEGIN
    DELETE FROM jobs
    WHERE job_id = p_job_id;

    rows_deleted := SQL%ROWCOUNT;

    IF rows_deleted = 0 THEN
        RAISE_APPLICATION_ERROR(-20002, 'No Jobs deleted for Job_id ' || p_job_id);
    ELSE
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Job deleted successfully: ' || p_job_id);
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END delete_job;
