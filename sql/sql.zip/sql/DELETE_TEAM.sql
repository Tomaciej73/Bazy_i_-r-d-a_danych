--------------------------------------------------------
--  DDL for Procedure DELETE_TEAM
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "DELETE_TEAM" (
    p_id IN NUMBER
) AS
BEGIN
    DELETE FROM Team WHERE ID = p_id;
    COMMIT;
END delete_team;
