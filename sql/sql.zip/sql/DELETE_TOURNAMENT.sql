--------------------------------------------------------
--  DDL for Procedure DELETE_TOURNAMENT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "DELETE_TOURNAMENT" (
    p_id IN NUMBER
) AS
BEGIN
    DELETE FROM Tournament WHERE ID = p_id;
    COMMIT;
END delete_tournament;
