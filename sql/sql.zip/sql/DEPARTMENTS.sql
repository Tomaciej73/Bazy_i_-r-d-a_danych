--------------------------------------------------------
--  DDL for Table DEPARTMENTS
--------------------------------------------------------

  CREATE TABLE "DEPARTMENTS" ("DEPARTMENT_ID" NUMBER, "DEPARTMENT_NAME" VARCHAR2(50), "MANAGER_ID" NUMBER, "LOCATION_ID" NUMBER)
