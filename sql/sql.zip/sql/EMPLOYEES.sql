--------------------------------------------------------
--  DDL for Table EMPLOYEES
--------------------------------------------------------

  CREATE TABLE "EMPLOYEES" ("EMPLOYEE_ID" NUMBER, "FIRST_NAME" VARCHAR2(50), "LAST_NAME" VARCHAR2(50), "EMAIL" VARCHAR2(100), "PHONE_NUMBER" VARCHAR2(20), "HIRE_DATE" DATE, "JOB_ID" VARCHAR2(10), "SALARY" NUMBER, "COMMISSION_PCT" NUMBER, "MANAGER_ID" NUMBER, "DEPARTMENT_ID" NUMBER)
