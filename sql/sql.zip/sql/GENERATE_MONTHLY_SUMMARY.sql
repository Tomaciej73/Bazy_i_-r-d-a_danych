--------------------------------------------------------
--  DDL for Procedure GENERATE_MONTHLY_SUMMARY
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "GENERATE_MONTHLY_SUMMARY" (
    p_year IN NUMBER, -- rok
    p_month IN NUMBER -- miesiąc
) AS
BEGIN
    -- Usunięcie istniejących danych dla danego roku i miesiąca
    DELETE FROM SUMMARY
     WHERE PERIOD_TYPE = 'MONTH'
       AND EXTRACT(YEAR FROM PERIOD_START_DATE) = p_year
       AND EXTRACT(MONTH FROM PERIOD_START_DATE) = p_month;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Dane z ' || p_year || '/' || p_month || ' istnieją, usuwam je i wstawiam ponownie');

    -- Pobranie danych do kursora
    FOR rec IN (
        SELECT
            'MONTH' AS PERIOD_TYPE,
            TO_DATE(p_year || '-' || p_month || '-01', 'YYYY-MM-DD') AS PERIOD_START_DATE,
            LAST_DAY(TO_DATE(p_year || '-' || p_month || '-01', 'YYYY-MM-DD')) AS PERIOD_END_DATE,
            T.ID AS TEAM_ID,
            T.TEAM_NAME,
            NVL(COUNT(G.ID), 0) AS MATCHES_PLAYED,
            NVL(SUM(CASE WHEN G.HOME_SCORE > G.AWAY_SCORE THEN 1 ELSE 0 END), 0) AS WINS,
            NVL(SUM(CASE WHEN G.HOME_SCORE = G.AWAY_SCORE THEN 1 ELSE 0 END), 0) AS DRAWS,
            NVL(SUM(CASE WHEN G.HOME_SCORE < G.AWAY_SCORE THEN 1 ELSE 0 END), 0) AS LOSSES,
            NVL(SUM(CASE WHEN G.HOME_TEAM_ID = T.ID THEN G.HOME_SCORE ELSE G.AWAY_SCORE END), 0) AS GOALS_FOR,
            NVL(SUM(CASE WHEN G.HOME_TEAM_ID = T.ID THEN G.AWAY_SCORE ELSE G.HOME_SCORE END), 0) AS GOALS_AGAINST,
            NVL(SUM(CASE WHEN G.HOME_SCORE > G.AWAY_SCORE THEN 3 
                         WHEN G.HOME_SCORE = G.AWAY_SCORE THEN 1 
                         ELSE 0 END), 0) AS POINTS
        FROM
            GAME G
        JOIN
            TEAM T ON (G.HOME_TEAM_ID = T.ID OR G.AWAY_TEAM_ID = T.ID)
        WHERE
            EXTRACT(YEAR FROM G.GAME_DATE) = p_year
            AND EXTRACT(MONTH FROM G.GAME_DATE) = p_month
        GROUP BY
            T.ID, T.TEAM_NAME
    ) LOOP
        -- Teraz wstawiamy każdy wiersz osobno, używając NEXTVAL bezpośrednio w VALUES
        INSERT INTO Summary (
            ID, PERIOD_TYPE, PERIOD_START_DATE, PERIOD_END_DATE, TEAM_ID, TEAM_NAME,
            MATCHES_PLAYED, WINS, DRAWS, LOSSES, GOALS_FOR, GOALS_AGAINST, POINTS
        )
        VALUES (
            SUMMARY_SEQ.NEXTVAL,
            rec.PERIOD_TYPE,
            rec.PERIOD_START_DATE,
            rec.PERIOD_END_DATE,
            rec.TEAM_ID,
            rec.TEAM_NAME,
            rec.MATCHES_PLAYED,
            rec.WINS,
            rec.DRAWS,
            rec.LOSSES,
            rec.GOALS_FOR,
            rec.GOALS_AGAINST,
            rec.POINTS
        );
    END LOOP;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Dane dla roku ' || p_year || ' i miesiąca ' || p_month || ' wstawiono poprawnie');
END;
