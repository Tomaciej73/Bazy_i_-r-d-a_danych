--------------------------------------------------------
--  DDL for Procedure GENERATE_YEARLY_SUMMARY
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "GENERATE_YEARLY_SUMMARY" (
    p_year IN NUMBER -- rok
) AS
BEGIN
    -- Najpierw usuwamy istniejące dane dla danego roku
    DELETE FROM SUMMARY
     WHERE PERIOD_TYPE = 'YEAR'
       AND EXTRACT(YEAR FROM PERIOD_START_DATE) = p_year;
       
    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Dane z ' || p_year || ' istnieja, usuwam');

    -- Pobranie danych do wstawienia
    FOR rec IN (
        SELECT
            'YEAR' AS PERIOD_TYPE,
            TO_DATE(p_year || '-01-01', 'YYYY-MM-DD') AS PERIOD_START_DATE,  
            TO_DATE(p_year || '-12-31', 'YYYY-MM-DD') AS PERIOD_END_DATE,
            T.ID AS TEAM_ID,
            T.TEAM_NAME,
            NVL(COUNT(G.ID), 0) AS MATCHES_PLAYED,
            NVL(SUM(CASE WHEN G.HOME_SCORE > G.AWAY_SCORE THEN 1 ELSE 0 END), 0) AS WINS,
            NVL(SUM(CASE WHEN G.HOME_SCORE = G.AWAY_SCORE THEN 1 ELSE 0 END), 0) AS DRAWS,
            NVL(SUM(CASE WHEN G.HOME_SCORE < G.AWAY_SCORE THEN 1 ELSE 0 END), 0) AS LOSSES,
            NVL(SUM(CASE WHEN G.HOME_TEAM_ID = T.ID THEN G.HOME_SCORE ELSE G.AWAY_SCORE END), 0) AS GOALS_FOR,
            NVL(SUM(CASE WHEN G.HOME_TEAM_ID = T.ID THEN G.AWAY_SCORE ELSE G.HOME_SCORE END), 0) AS GOALS_AGAINST,
            NVL(SUM(CASE WHEN G.HOME_SCORE > G.AWAY_SCORE THEN 3
                         WHEN G.HOME_SCORE = G.AWAY_SCORE THEN 1
                         ELSE 0 END), 0) AS POINTS
        FROM
            GAME G
        JOIN
            TEAM T ON G.HOME_TEAM_ID = T.ID
        WHERE
            EXTRACT(YEAR FROM G.GAME_DATE) = p_year
        GROUP BY
            T.ID, T.TEAM_NAME
        UNION ALL
        SELECT
            'YEAR' AS PERIOD_TYPE,
            TO_DATE(p_year || '-01-01', 'YYYY-MM-DD') AS PERIOD_START_DATE,  
            TO_DATE(p_year || '-12-31', 'YYYY-MM-DD') AS PERIOD_END_DATE,
            T.ID AS TEAM_ID,
            T.TEAM_NAME,
            NVL(COUNT(G.ID), 0) AS MATCHES_PLAYED,
            NVL(SUM(CASE WHEN G.AWAY_SCORE > G.HOME_SCORE THEN 1 ELSE 0 END), 0) AS WINS,
            NVL(SUM(CASE WHEN G.AWAY_SCORE = G.HOME_SCORE THEN 1 ELSE 0 END), 0) AS DRAWS,
            NVL(SUM(CASE WHEN G.AWAY_SCORE < G.HOME_SCORE THEN 1 ELSE 0 END), 0) AS LOSSES,
            NVL(SUM(CASE WHEN G.AWAY_TEAM_ID = T.ID THEN G.AWAY_SCORE ELSE G.HOME_SCORE END), 0) AS GOALS_FOR,
            NVL(SUM(CASE WHEN G.AWAY_TEAM_ID = T.ID THEN G.HOME_SCORE ELSE G.AWAY_SCORE END), 0) AS GOALS_AGAINST,
            NVL(SUM(CASE WHEN G.AWAY_SCORE > G.HOME_SCORE THEN 3
                         WHEN G.AWAY_SCORE = G.HOME_SCORE THEN 1
                         ELSE 0 END), 0) AS POINTS
        FROM
            GAME G
        JOIN
            TEAM T ON G.AWAY_TEAM_ID = T.ID
        WHERE
            EXTRACT(YEAR FROM G.GAME_DATE) = p_year
        GROUP BY
            T.ID, T.TEAM_NAME
    ) LOOP
        DBMS_OUTPUT.PUT_LINE('Wstawiam dane z tabeli TEAM ' || rec.TEAM_NAME);

        INSERT INTO Summary (
            ID, PERIOD_TYPE, PERIOD_START_DATE, PERIOD_END_DATE, TEAM_ID, TEAM_NAME,
            MATCHES_PLAYED, WINS, DRAWS, LOSSES, GOALS_FOR, GOALS_AGAINST, POINTS
        )
        VALUES (
            SUMMARY_SEQ.NEXTVAL, -- Bezpośrednie użycie sekwencji
            rec.PERIOD_TYPE, 
            rec.PERIOD_START_DATE, 
            rec.PERIOD_END_DATE, 
            rec.TEAM_ID, 
            rec.TEAM_NAME,
            rec.MATCHES_PLAYED, 
            rec.WINS, 
            rec.DRAWS, 
            rec.LOSSES, 
            rec.GOALS_FOR, 
            rec.GOALS_AGAINST, 
            rec.POINTS
        );
    END LOOP;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Dane dla roku ' || p_year || ' wstawiono poprawnie');
END;
