--------------------------------------------------------
--  DDL for Function GET_ALL_CITIES
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "GET_ALL_CITIES" RETURN SYS_REFCURSOR IS
    cities_cursor SYS_REFCURSOR;
BEGIN
    OPEN cities_cursor FOR
    SELECT * FROM City;
    RETURN cities_cursor;
END get_all_cities;
