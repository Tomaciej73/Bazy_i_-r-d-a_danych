--------------------------------------------------------
--  DDL for Function GET_ALL_COUNTRIES
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "GET_ALL_COUNTRIES" RETURN SYS_REFCURSOR IS
    countries_cursor SYS_REFCURSOR;
BEGIN
    OPEN countries_cursor FOR
    SELECT * FROM Country;
    RETURN countries_cursor;
END get_all_countries;
