--------------------------------------------------------
--  DDL for Function GET_ALL_GAME
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "GET_ALL_GAME" RETURN SYS_REFCURSOR IS
    matches_cursor SYS_REFCURSOR;
BEGIN
    OPEN matches_cursor FOR
    SELECT * FROM GAME;
    RETURN matches_cursor;
END get_all_game;
