--------------------------------------------------------
--  DDL for Function GET_ALL_TEAMS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "GET_ALL_TEAMS" RETURN SYS_REFCURSOR IS
    teams_cursor SYS_REFCURSOR;
BEGIN
    OPEN teams_cursor FOR
    SELECT * FROM Team;
    RETURN teams_cursor;
END get_all_teams;
