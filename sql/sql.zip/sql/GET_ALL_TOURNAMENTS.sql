--------------------------------------------------------
--  DDL for Function GET_ALL_TOURNAMENTS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "GET_ALL_TOURNAMENTS" RETURN SYS_REFCURSOR IS
    tournaments_cursor SYS_REFCURSOR;
BEGIN
    OPEN tournaments_cursor FOR
    SELECT * FROM Tournament;
    RETURN tournaments_cursor;
END get_all_tournaments;
