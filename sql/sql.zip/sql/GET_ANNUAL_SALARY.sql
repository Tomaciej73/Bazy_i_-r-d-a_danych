--------------------------------------------------------
--  DDL for Function GET_ANNUAL_SALARY
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "GET_ANNUAL_SALARY" (p_employee_id IN NUMBER) 
RETURN NUMBER IS
    v_salary NUMBER;
    v_commission_pct NUMBER;
    v_annual_salary NUMBER;
BEGIN
    SELECT salary, commission_pct
    INTO v_salary, v_commission_pct
    FROM employees
    WHERE employee_id = p_employee_id;

    IF v_commission_pct IS NULL THEN
        v_commission_pct := 0;
    END IF;

    v_annual_salary := (v_salary * 12) + (v_salary * v_commission_pct);

    RETURN v_annual_salary;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20002, 'Employee with ID ' || p_employee_id || ' not found.');
    WHEN OTHERS THEN
        RAISE;
END get_annual_salary;
