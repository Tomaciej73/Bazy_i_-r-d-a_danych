--------------------------------------------------------
--  DDL for Function GET_BIRTHDATE_FROM_PESEL
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "GET_BIRTHDATE_FROM_PESEL" (p_pesel IN VARCHAR2) 
RETURN DATE IS
    v_birthdate DATE;
BEGIN
    v_birthdate := TO_DATE('19' || SUBSTR(p_pesel, 1, 2) || '-' || 
                            SUBSTR(p_pesel, 3, 2) || '-' || 
                            SUBSTR(p_pesel, 5, 2), 'YYYY-MM-DD');

    RETURN v_birthdate;
EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20004, 'Invalid PESEL format');
END get_birthdate_from_pesel;
