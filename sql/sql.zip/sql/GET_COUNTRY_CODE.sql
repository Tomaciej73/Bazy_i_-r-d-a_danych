--------------------------------------------------------
--  DDL for Function GET_COUNTRY_CODE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "GET_COUNTRY_CODE" (p_phone_number IN VARCHAR2) 
RETURN VARCHAR2 IS
    v_country_code VARCHAR2(10);
BEGIN
    v_country_code := REGEXP_SUBSTR(p_phone_number, '^\+(\d+)');

    IF v_country_code IS NULL THEN
        RAISE_APPLICATION_ERROR(-20003, 'Invalid phone number format');
    END IF;

    RETURN v_country_code;
EXCEPTION
    WHEN OTHERS THEN
        RAISE;
END get_country_code;
