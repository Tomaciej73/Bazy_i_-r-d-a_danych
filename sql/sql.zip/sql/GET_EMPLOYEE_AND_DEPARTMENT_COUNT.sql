--------------------------------------------------------
--  DDL for Function GET_EMPLOYEE_AND_DEPARTMENT_COUNT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "GET_EMPLOYEE_AND_DEPARTMENT_COUNT" (p_country_name IN VARCHAR2) 
RETURN VARCHAR2 IS
    v_employee_count NUMBER;
    v_department_count NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO v_employee_count
    FROM employees e
    JOIN departments d ON e.department_id = d.department_id
    JOIN locations l ON d.location_id = l.location_id
    JOIN countries c ON l.country_id = c.country_id
    WHERE c.country_name = p_country_name;

    SELECT COUNT(*)
    INTO v_department_count
    FROM departments d
    JOIN locations l ON d.location_id = l.location_id
    JOIN countries c ON l.country_id = c.country_id
    WHERE c.country_name = p_country_name;

    RETURN 'Employees: ' || v_employee_count || ', Departments: ' || v_department_count;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20005, 'Country not found: ' || p_country_name);
    WHEN OTHERS THEN
        RAISE;
END get_employee_and_department_count;
