--------------------------------------------------------
--  DDL for Procedure GET_EMPLOYEE_SALARY
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "GET_EMPLOYEE_SALARY" (
    p_employee_id IN NUMBER, 
    p_salary OUT NUMBER, 
    p_last_name OUT VARCHAR2
) AS
BEGIN
    SELECT salary, last_name
    INTO p_salary, p_last_name
    FROM employees
    WHERE employee_id = p_employee_id;

    DBMS_OUTPUT.PUT_LINE('Employee: ' || p_last_name || ', Salary: ' || p_salary);

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Error: No employee found with ID ' || p_employee_id);
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END get_employee_salary;
