--------------------------------------------------------
--  DDL for Function GET_JOB_NAME
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "GET_JOB_NAME" (p_job_id IN VARCHAR2) 
RETURN VARCHAR2 IS
    v_job_title VARCHAR2(255);
BEGIN
    SELECT job_title
    INTO v_job_title
    FROM jobs
    WHERE job_id = p_job_id;

    RETURN v_job_title;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'Job with ID ' || p_job_id || ' does not exist.');
    WHEN OTHERS THEN
        RAISE;
END get_job_name;
