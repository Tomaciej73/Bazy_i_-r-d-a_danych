--------------------------------------------------------
--  DDL for Table JOB_HISTORY
--------------------------------------------------------

  CREATE TABLE "JOB_HISTORY" ("EMPLOYEE_ID" NUMBER, "START_DATE" DATE, "END_DATE" DATE, "JOB_ID" VARCHAR2(10), "DEPARTMENT_ID" NUMBER)
