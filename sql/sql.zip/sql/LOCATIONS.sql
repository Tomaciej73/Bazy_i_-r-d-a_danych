--------------------------------------------------------
--  DDL for Table LOCATIONS
--------------------------------------------------------

  CREATE TABLE "LOCATIONS" ("LOCATION_ID" NUMBER, "STREET_ADDRESS" VARCHAR2(100), "POSTAL_CODE" VARCHAR2(20), "CITY" VARCHAR2(50), "STATE_PROVINCE" VARCHAR2(50), "COUNTRY_ID" CHAR(2))
