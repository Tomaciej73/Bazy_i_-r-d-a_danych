--------------------------------------------------------
--  DDL for Trigger LOG_DELETE_ON_CITY
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "LOG_DELETE_ON_CITY" 
AFTER DELETE ON city
FOR EACH ROW
BEGIN
    INSERT INTO operation_logs (
          log_id,
        operation_type, 
        table_name, 
        rows_affected, 
        executed_by, 
        execution_time, 
        details
    ) 
    VALUES (
        operation_log_seq.NEXTVAL,
        'DELETE', 
        'CITIES', 
        1, 
        USER, 
        CURRENT_TIMESTAMP, 
        'Deleted city: ' || :OLD.city_name
    );
END;
ALTER TRIGGER "LOG_DELETE_ON_CITY" ENABLE
