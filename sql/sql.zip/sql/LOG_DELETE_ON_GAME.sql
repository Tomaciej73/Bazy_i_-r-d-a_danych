--------------------------------------------------------
--  DDL for Trigger LOG_DELETE_ON_GAME
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "LOG_DELETE_ON_GAME" 
AFTER DELETE ON game
FOR EACH ROW
BEGIN
    INSERT INTO operation_logs (
          log_id,
        operation_type, 
        table_name, 
        rows_affected, 
        executed_by, 
        execution_time, 
        details
    ) 
    VALUES (
        operation_log_seq.NEXTVAL,
        'DELETE', 
        'GAMES', 
        1, 
        USER, 
        CURRENT_TIMESTAMP, 
        'Deleted game with ID: ' || :OLD.id
    );
END;
ALTER TRIGGER "LOG_DELETE_ON_GAME" ENABLE
