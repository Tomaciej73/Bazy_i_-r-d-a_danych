--------------------------------------------------------
--  DDL for Trigger LOG_DELETE_ON_TOURNAMENT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "LOG_DELETE_ON_TOURNAMENT" 
AFTER DELETE ON tournament
FOR EACH ROW
BEGIN
    INSERT INTO operation_logs (
          log_id,
        operation_type, 
        table_name, 
        rows_affected, 
        executed_by, 
        execution_time, 
        details
    ) 
    VALUES (
        operation_log_seq.NEXTVAL,
        'DELETE', 
        'TOURNAMENTS', 
        1, 
        USER, 
        CURRENT_TIMESTAMP, 
        'Deleted tournament: ' || :OLD.tournament_name
    );
END;
ALTER TRIGGER "LOG_DELETE_ON_TOURNAMENT" ENABLE
