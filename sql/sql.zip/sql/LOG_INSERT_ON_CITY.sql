--------------------------------------------------------
--  DDL for Trigger LOG_INSERT_ON_CITY
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "LOG_INSERT_ON_CITY" 
AFTER INSERT ON city
FOR EACH ROW
BEGIN
    INSERT INTO operation_logs (
        log_id,
        operation_type, 
        table_name, 
        rows_affected, 
        executed_by, 
        execution_time, 
        details
    ) 
    VALUES (
        operation_log_seq.NEXTVAL,
        'INSERT', 
        'CITIES', 
        1, 
        USER, 
        CURRENT_TIMESTAMP, 
        'Inserted new city: ' || :NEW.city_name
    );
END;
ALTER TRIGGER "LOG_INSERT_ON_CITY" ENABLE
