--------------------------------------------------------
--  DDL for Trigger LOG_INSERT_ON_COUNTRY
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "LOG_INSERT_ON_COUNTRY" 
AFTER INSERT ON country
FOR EACH ROW
BEGIN
    INSERT INTO operation_logs (
          log_id,
        operation_type, 
        table_name, 
        rows_affected, 
        executed_by, 
        execution_time, 
        details
    ) 
    VALUES (
        operation_log_seq.NEXTVAL,
        'INSERT', 
        'COUNTRIES', 
        1, 
        USER, 
        CURRENT_TIMESTAMP, 
        'Inserted new country: ' || :NEW.country_name
    );
END;
ALTER TRIGGER "LOG_INSERT_ON_COUNTRY" ENABLE
