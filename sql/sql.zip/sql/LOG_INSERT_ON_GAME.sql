--------------------------------------------------------
--  DDL for Trigger LOG_INSERT_ON_GAME
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "LOG_INSERT_ON_GAME" 
AFTER INSERT ON game
FOR EACH ROW
BEGIN
    INSERT INTO operation_logs (
        log_id,
        operation_type, 
        table_name, 
        rows_affected, 
        executed_by, 
        execution_time, 
        details
    ) 
    VALUES (
        operation_log_seq.NEXTVAL,
        'INSERT', 
        'GAMES', 
        1, 
        USER, 
        CURRENT_TIMESTAMP, 
        'Inserted new game with ID: ' || :NEW.id || ', Home Team ID: ' || :NEW.home_team_id || ', Away Team ID: ' || :NEW.away_team_id
    );
END;
ALTER TRIGGER "LOG_INSERT_ON_GAME" ENABLE
