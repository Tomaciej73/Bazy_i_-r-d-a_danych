--------------------------------------------------------
--  DDL for Trigger LOG_INSERT_ON_TEAM
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "LOG_INSERT_ON_TEAM" 
AFTER INSERT ON team
FOR EACH ROW
BEGIN
    INSERT INTO operation_logs (
        log_id,
        operation_type, 
        table_name, 
        rows_affected, 
        executed_by, 
        execution_time, 
        details
    ) 
    VALUES (
        operation_log_seq.NEXTVAL,
        'INSERT', 
        'TEAMS', 
        1, 
        USER, 
        CURRENT_TIMESTAMP, 
        'Inserted new team: ' || :NEW.team_name
    );
END;
ALTER TRIGGER "LOG_INSERT_ON_TEAM" ENABLE
