--------------------------------------------------------
--  DDL for Trigger LOG_INSERT_ON_TOURNAMENT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "LOG_INSERT_ON_TOURNAMENT" 
AFTER INSERT ON tournament
FOR EACH ROW
BEGIN
    INSERT INTO operation_logs (
        log_id,
        operation_type, 
        table_name, 
        rows_affected, 
        executed_by, 
        execution_time, 
        details
    ) 
    VALUES (
        operation_log_seq.NEXTVAL,
        'INSERT', 
        'TOURNAMENTS', 
        1, 
        USER, 
        CURRENT_TIMESTAMP, 
        'Inserted new tournament: ' || :NEW.tournament_name
    );
END;
ALTER TRIGGER "LOG_INSERT_ON_TOURNAMENT" ENABLE
