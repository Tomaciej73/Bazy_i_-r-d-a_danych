--------------------------------------------------------
--  DDL for Trigger LOG_UPDATE_ON_CITY
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "LOG_UPDATE_ON_CITY" 
AFTER UPDATE ON city
FOR EACH ROW
BEGIN
    INSERT INTO operation_logs (
        log_id,
        operation_type, 
        table_name, 
        rows_affected, 
        executed_by, 
        execution_time, 
        details
    ) 
    VALUES (
        operation_log_seq.NEXTVAL,
        'UPDATE', 
        'CITIES', 
        1, 
        USER, 
        CURRENT_TIMESTAMP, 
        'Updated city: ' || :OLD.city_name || ' to ' || :NEW.city_name
    );
END;
ALTER TRIGGER "LOG_UPDATE_ON_CITY" ENABLE
