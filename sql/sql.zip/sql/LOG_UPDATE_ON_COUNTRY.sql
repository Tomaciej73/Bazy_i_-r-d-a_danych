--------------------------------------------------------
--  DDL for Trigger LOG_UPDATE_ON_COUNTRY
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "LOG_UPDATE_ON_COUNTRY" 
AFTER UPDATE ON country
FOR EACH ROW
BEGIN
    INSERT INTO operation_logs (
        log_id,
        operation_type, 
        table_name, 
        rows_affected, 
        executed_by, 
        execution_time, 
        details
    ) 
    VALUES (
        operation_log_seq.NEXTVAL,
        'UPDATE', 
        'COUNTRIES', 
        1, 
        USER, 
        CURRENT_TIMESTAMP, 
        'Updated country: ' || :OLD.country_name || ' to ' || :NEW.country_name
    );
END;
ALTER TRIGGER "LOG_UPDATE_ON_COUNTRY" ENABLE
