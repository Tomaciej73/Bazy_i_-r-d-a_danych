--------------------------------------------------------
--  DDL for Trigger LOG_UPDATE_ON_GAME
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "LOG_UPDATE_ON_GAME" 
AFTER UPDATE ON game
FOR EACH ROW
BEGIN
    INSERT INTO operation_logs (
        log_id,
        operation_type, 
        table_name, 
        rows_affected, 
        executed_by, 
        execution_time, 
        details
    ) 
    VALUES (
        operation_log_seq.NEXTVAL,
        'UPDATE', 
        'GAMES', 
        1, 
        USER, 
        CURRENT_TIMESTAMP, 
        'Updated game ID: ' || :OLD.id || ' to new data'
    );
END;
ALTER TRIGGER "LOG_UPDATE_ON_GAME" ENABLE
