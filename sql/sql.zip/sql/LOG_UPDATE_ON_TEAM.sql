--------------------------------------------------------
--  DDL for Trigger LOG_UPDATE_ON_TEAM
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "LOG_UPDATE_ON_TEAM" 
AFTER UPDATE ON team
FOR EACH ROW
BEGIN
    INSERT INTO operation_logs (
        log_id,
        operation_type, 
        table_name, 
        rows_affected, 
        executed_by, 
        execution_time, 
        details
    ) 
    VALUES (
        operation_log_seq.NEXTVAL,
        'UPDATE', 
        'TEAMS', 
        1, 
        USER, 
        CURRENT_TIMESTAMP, 
        'Updated team: ' || :OLD.team_name || ' to ' || :NEW.team_name
    );
END;
ALTER TRIGGER "LOG_UPDATE_ON_TEAM" ENABLE
