--------------------------------------------------------
--  DDL for Trigger LOG_UPDATE_ON_TOURNAMENT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "LOG_UPDATE_ON_TOURNAMENT" 
AFTER UPDATE ON tournament
FOR EACH ROW
BEGIN
    INSERT INTO operation_logs (
        log_id,
        operation_type, 
        table_name, 
        rows_affected, 
        executed_by, 
        execution_time, 
        details
    ) 
    VALUES (
        operation_log_seq.NEXTVAL,
        'UPDATE', 
        'TOURNAMENTS', 
        1, 
        USER, 
        CURRENT_TIMESTAMP, 
        'Updated tournament: ' || :OLD.tournament_name || ' to ' || :NEW.tournament_name
    );
END;
ALTER TRIGGER "LOG_UPDATE_ON_TOURNAMENT" ENABLE
