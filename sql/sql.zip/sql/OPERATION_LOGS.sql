--------------------------------------------------------
--  DDL for Table OPERATION_LOGS
--------------------------------------------------------

  CREATE TABLE "OPERATION_LOGS" ("LOG_ID" NUMBER, "OPERATION_TYPE" VARCHAR2(50), "TABLE_NAME" VARCHAR2(255), "ROWS_AFFECTED" NUMBER, "EXECUTED_BY" VARCHAR2(255), "EXECUTION_TIME" TIMESTAMP (6) DEFAULT CURRENT_TIMESTAMP, "DETAILS" VARCHAR2(4000))
