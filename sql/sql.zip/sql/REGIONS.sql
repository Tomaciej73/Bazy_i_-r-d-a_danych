--------------------------------------------------------
--  DDL for Table REGIONS
--------------------------------------------------------

  CREATE TABLE "REGIONS" ("REGION_ID" NUMBER, "REGION_NAME" VARCHAR2(50))
