--------------------------------------------------------
--  DDL for Trigger TRG_ARCHIVE_DEPARTMENT
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_ARCHIVE_DEPARTMENT" 
AFTER DELETE ON departments
FOR EACH ROW
BEGIN
    INSERT INTO archive_departments (id, department_name, closure_date, last_manager)
    VALUES (:OLD.department_id, :OLD.department_name, SYSDATE, 
            (SELECT first_name || ' ' || last_name 
             FROM employees 
             WHERE employee_id = :OLD.manager_id));
END;
/
ALTER TRIGGER "TRG_ARCHIVE_DEPARTMENT" ENABLE
