--------------------------------------------------------
--  DDL for Trigger TRG_AUTO_INCREMENT_EMPLOYEE
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_AUTO_INCREMENT_EMPLOYEE" 
BEFORE INSERT ON employees
FOR EACH ROW
BEGIN
    SELECT employee_seq.NEXTVAL INTO :NEW.employee_id FROM dual;
END;

ALTER TRIGGER "TRG_AUTO_INCREMENT_EMPLOYEE" ENABLE
