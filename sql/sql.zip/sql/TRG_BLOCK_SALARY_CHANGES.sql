--------------------------------------------------------
--  DDL for Trigger TRG_BLOCK_SALARY_CHANGES
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_BLOCK_SALARY_CHANGES" 
BEFORE UPDATE ON jobs
FOR EACH ROW
BEGIN
    IF :NEW.min_salary <> :OLD.min_salary OR :NEW.max_salary <> :OLD.max_salary THEN
        :NEW.min_salary := :OLD.min_salary;
        :NEW.max_salary := :OLD.max_salary;
    END IF;
END;

ALTER TRIGGER "TRG_BLOCK_SALARY_CHANGES" ENABLE
