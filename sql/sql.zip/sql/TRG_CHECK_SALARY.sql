--------------------------------------------------------
--  DDL for Trigger TRG_CHECK_SALARY
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "TRG_CHECK_SALARY" 
BEFORE INSERT OR UPDATE ON employees
FOR EACH ROW
BEGIN
    IF :NEW.salary < 2000 OR :NEW.salary > 26000 THEN
        RAISE_APPLICATION_ERROR(-20006, 'Salary must be between 2000 and 26000.');
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        INSERT INTO złodziej (id, user, czas_zmiany)
        VALUES (:NEW.employee_id, USER, SYSDATE);
END;

ALTER TRIGGER "TRG_CHECK_SALARY" ENABLE
