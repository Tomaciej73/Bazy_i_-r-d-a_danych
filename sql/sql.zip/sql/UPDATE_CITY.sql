--------------------------------------------------------
--  DDL for Procedure UPDATE_CITY
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "UPDATE_CITY" (
    p_id IN NUMBER,
    p_city_name IN VARCHAR2
) AS
BEGIN
    UPDATE City
    SET CITY_NAME = p_city_name
    WHERE ID = p_id;
    COMMIT;
END update_city;
