--------------------------------------------------------
--  DDL for Procedure UPDATE_COUNTRY
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "UPDATE_COUNTRY" (
    p_id IN NUMBER,
    p_country_name IN VARCHAR2
) AS
BEGIN
    UPDATE Country
    SET COUNTRY_NAME = p_country_name
    WHERE ID = p_id;
    COMMIT;
END update_country;
