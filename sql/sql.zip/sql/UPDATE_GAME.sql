--------------------------------------------------------
--  DDL for Procedure UPDATE_GAME
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "UPDATE_GAME" (
    p_id IN NUMBER,
    p_game_date IN DATE,
    p_home_team_id IN NUMBER,
    p_away_team_id IN NUMBER,
    p_home_score IN NUMBER,
    p_away_score IN NUMBER,
    p_tournament_id IN NUMBER,
    p_city_id IN NUMBER,
    p_country_id IN NUMBER,
    p_neutral IN NUMBER
) AS
BEGIN
    UPDATE GAME
    SET GAME_DATE = p_game_date,
        HOME_TEAM_ID = p_home_team_id,
        AWAY_TEAM_ID = p_away_team_id,
        HOME_SCORE = p_home_score,
        AWAY_SCORE = p_away_score,
        TOURNAMENT_ID = p_tournament_id,
        CITY_ID = p_city_id,
        COUNTRY_ID = p_country_id,
        NEUTRAL = p_neutral
    WHERE ID = p_id;
    COMMIT;
END update_game;
