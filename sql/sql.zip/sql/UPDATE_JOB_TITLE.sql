--------------------------------------------------------
--  DDL for Procedure UPDATE_JOB_TITLE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "UPDATE_JOB_TITLE" (
    p_job_id IN VARCHAR2, 
    p_new_job_title IN VARCHAR2
) AS
    rows_updated INTEGER;
BEGIN
    UPDATE jobs
    SET job_title = p_new_job_title
    WHERE job_id = p_job_id;

    rows_updated := SQL%ROWCOUNT;

    IF rows_updated = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'No Jobs updated for Job_id ' || p_job_id);
    ELSE
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Job updated successfully: ' || p_job_id || ' - ' || p_new_job_title);
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END update_job_title;
