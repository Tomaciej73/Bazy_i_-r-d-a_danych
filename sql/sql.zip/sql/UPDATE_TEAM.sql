--------------------------------------------------------
--  DDL for Procedure UPDATE_TEAM
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "UPDATE_TEAM" (
    p_id IN NUMBER,
    p_team_name IN VARCHAR2
) AS
BEGIN
    UPDATE Team
    SET TEAM_NAME = p_team_name
    WHERE ID = p_id;
    COMMIT;
END update_team;
