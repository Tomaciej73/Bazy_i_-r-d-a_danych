--------------------------------------------------------
--  DDL for Procedure UPDATE_TOURNAMENT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "UPDATE_TOURNAMENT" (
    p_id IN NUMBER,
    p_tournament_name IN VARCHAR2
) AS
BEGIN
    UPDATE Tournament
    SET TOURNAMENT_NAME = p_tournament_name
    WHERE ID = p_id;
    COMMIT;
END update_tournament;
